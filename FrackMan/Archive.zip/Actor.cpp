#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp

void FrackMan::doSomething(){
    int input;
    //MAKE SURE IT DOESN'T LEAVE
    if(getWorld()->getKey(input) == true){
        switch (input) {
            case KEY_PRESS_LEFT:
                if(getDirection() == left && getX() > 0)
                    moveTo(getX() - 1, getY());
                else
                    setDirection(left);
                break;
            case KEY_PRESS_RIGHT:
                 if(getDirection() == right && getX() < VIEW_WIDTH - SPRITE_WIDTH)
                    moveTo(getX() + 1, getY());
                else
                    setDirection(right);
                break;
            case KEY_PRESS_DOWN:
                if(getDirection() == down && getY() > 0)
                    moveTo(getX(), getY() - 1);
                else
                    setDirection(down);
                break;
            case KEY_PRESS_UP:
                if(getDirection() == up && getY() < VIEW_HEIGHT - SPRITE_HEIGHT)
                    moveTo(getX(), getY() + 1);
                else
                    setDirection(up);
                break;
            default:
                break;
        }
    }
    for(int x = 0; x<SPRITE_WIDTH; x++){
        for(int y = 0; y<SPRITE_HEIGHT; y++){
            if(getWorld()->hasDirt(getX() + x, getY() + y)){
                getWorld()->removeDirt(getX() + x, getY() + y);
            }
        }
    }
    
//    getX()
}

void FrackMan::getAnnoyed(){
    
}