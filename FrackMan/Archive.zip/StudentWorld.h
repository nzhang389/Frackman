#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include <string>

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class Dirt;
class FrackMan;
class Actor;

class StudentWorld : public GameWorld
{
public:
    StudentWorld(std::string assetDir);
    virtual ~StudentWorld(){
        cleanUp();
    }

    virtual int init();

    
    virtual int move();
	

    virtual void cleanUp();
	

    void removeDirt(int x, int y);

    bool hasDirt(int x, int y){
        if (x >= 0 && x < VIEW_WIDTH && y >= 0 && y < VIEW_HEIGHT && m_dirt[x][y] != nullptr)
            return true;
        return false;
    }
private:
    Dirt *** m_dirt;
    FrackMan * m_frackman;
    
};

#endif // STUDENTWORLD_H_
