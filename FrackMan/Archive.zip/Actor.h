#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

class StudentWorld;



// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
class Actor: public GraphObject {
public:
    Actor(StudentWorld* sw, int imageID, int startX, int startY, Direction dir = right, double size = 1.0, unsigned int depth = 0): GraphObject(imageID, startX, startY, dir, size, depth){
        m_world = sw;
    }
    virtual ~Actor(){
        
    }
    StudentWorld * getWorld(){
        return m_world;
    }
    virtual void doSomething() = 0;
    virtual void getAnnoyed() = 0;
private:
    StudentWorld * m_world;
};

class Dirt: public Actor {
public:
    Dirt(StudentWorld* sw, int startX, int startY): Actor(sw, IID_DIRT, startX, startY, right, 0.25, 3) {
        GraphObject::setVisible(true);
    }
    virtual ~Dirt(){
        
    }
    virtual void doSomething(){};
    virtual void getAnnoyed(){};
private:
    
};

class Man: public Actor{
public:
    Man(StudentWorld* sw, int imageID, int startX, int startY, Direction dir): Actor(sw, imageID, startX, startY, dir) {
    }
    virtual ~Man(){}
    int myHealth() const{
        return m_health;
    }
    void takDamage(int amt){
        m_health -= amt;
    }
    virtual void doSomething() = 0;
    virtual void getAnnoyed() = 0;
private:
    int m_health;
};

class FrackMan: public Man{
public:
    FrackMan(StudentWorld* sw): Man(sw, IID_PLAYER, 30, 60, right){
        GraphObject::setVisible(true);
    }
    virtual ~FrackMan(){}
    virtual void doSomething();
    virtual void getAnnoyed();
        
    private:
    
};


#endif // ACTOR_H_
