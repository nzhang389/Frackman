#include "StudentWorld.h"
#include "Actor.h"
#include <string>

using namespace std;

void StudentWorld::cleanUp() {
    for(int x = 0; x<64; x++){
        for(int y = 0; y<64;y++){
            if(m_dirt[x][y] != nullptr)
                delete m_dirt[x][y];
        }
    }
    if (m_frackman != nullptr)
        delete m_frackman;
}

GameWorld* createStudentWorld(string assetDir)
{
    StudentWorld * temp = new StudentWorld(assetDir);
    return temp;
}

int StudentWorld::move(){
    m_frackman->doSomething();
    // This code is here merely to allow the game to build, run, and terminate after you hit enter a few times.
    // Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
    //		decLives();
    //		return GWSTATUS_PLAYER_DIED;
    return GWSTATUS_CONTINUE_GAME;
}

// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp


void StudentWorld::removeDirt(int x, int y) {
    delete m_dirt[x][y];
    m_dirt[x][y] = nullptr;
}

int StudentWorld::init(){
    m_dirt = new Dirt**[VIEW_WIDTH];
	for(int x = 0; x<VIEW_WIDTH; x++){
        m_dirt[x] = new Dirt*[VIEW_HEIGHT];
        for(int y = 0; y<VIEW_HEIGHT; y++){
            m_dirt[x][y] = nullptr;
            if(x>=30 && x<=33){
                if(y>=0 && y <= 3){
                    m_dirt[x][y] = new Dirt(this,x,y);
                }
            }
            else {
                if(y<60)
                    m_dirt[x][y] = new Dirt(this,x,y);
            }
        }
    }
    m_frackman = new FrackMan(this);
    return GWSTATUS_CONTINUE_GAME;
}

StudentWorld::StudentWorld(std::string assetDir)
: GameWorld(assetDir)
{
    
}